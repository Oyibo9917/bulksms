<div>
    <div style="display: flex; align-items: center; align-content: center; margin:auto;">
        <img src="{{ asset('images/logo_1.png') }}" alt="logo" width="60px" height="60px" style="margin-right: .5rem;">

        <div class="name">
            <div>
                <div class="top" style="font-weight: bolder; font-size: 1.3rem;color:green;">LANA</div>
                <hr style="border-color: #fe0000; width: 100%;">
                <div class="bottom" style="font-weight: bold; font-size: .9rem;color:red;">Hospital</div>
            </div>
        </div>
    </div>
</div>

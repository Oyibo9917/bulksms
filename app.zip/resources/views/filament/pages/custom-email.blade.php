<x-filament-panels::page>
    <div class="d-flex justify-content-center align-items-center">
        <img width="35%" src="{{ asset('images/work_under_construction.webp') }}" alt="Under Construction" style="margin: auto;">
    </div>
</x-filament-panels::page>
